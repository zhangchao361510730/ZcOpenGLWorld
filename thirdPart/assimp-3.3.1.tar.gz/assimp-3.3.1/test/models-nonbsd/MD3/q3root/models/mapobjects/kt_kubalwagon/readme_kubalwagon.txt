-------------------------------------------------------------------------

TITLE : kt_kubalwagon
AUTHOR : ken 'kat' beyer
EMAIL ADDRESS : cpdt@telinco.co.uk
HOMEPAGE URL : http://www.quake3bits.co.uk
NUMBER OF MODELS : 1
SHADER SCRIPTS : yes - included

------------------
* MODEL NAME/s *
[model details below]
european_fnt_v2.md3

euro_rnt_2.tga (alpha'd steering wheel)
european_fnt.tga


------------------

CREDITS
ID software, eskimo roll, EMSIPE, QkenneyQ
DISTRIBUTION
as long as this readme is included...!

--------------------------------------------------------------------------