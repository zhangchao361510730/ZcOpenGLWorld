Made by me (Richard Mitton).
I waive all rights to this and release it into the public domain.
Do with it as you wish.
